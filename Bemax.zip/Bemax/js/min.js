$('document').ready (function (){

// Sticky Menu
$(window).on('scroll',function() {    
    var scroll = $(window).scrollTop();
    if (scroll < 1) {
     $(".sticky").removeClass("scroll-header");
    }else{
     $(".sticky").addClass("scroll-header");
    }
   });




    jQuery('#mobile-menu').meanmenu({
        meanScreenWidth: "767",
        meanMenuContainer: '.menu-place'
    });


//  slider-active
    $('.slider-active').owlCarousel({
        loop:true,
        nav:true,
        navText:['<i class="fas fa-chevron-left"></i>','<i class="fas fa-chevron-right"></i>'],
        responsive:{
            0:{
                items:1
            },
            600:{
                items:1
            },
            1000:{
                items:1
            }
        }
    });


 // project-active
    $('.project-active').owlCarousel({
      loop:true,
      nav:true,
      navText:['<i class="fas fa-chevron-left"></i>','<i class="fas fa-chevron-right"></i>'],
      responsive:{
          0:{
              items:1
          },
          600:{
              items:1
          },
          768:{
              items:2
          },
          1000:{
              items:4
          }
      }
  })


    // blog-active
    $('.blog-active').owlCarousel({
      loop:true,
      nav:true,
      navText:['<i class="fas fa-chevron-left"></i>','<i class="fas fa-chevron-right"></i>'],
      responsive:{
          0:{
              items:1
          },
          600:{
              items:1
          },
          768:{
              items:1
          },
          1000:{
              items:1
          }
      }
  })

  // .blog-wrapper-right
    $('.blog-wrapper-right-active').owlCarousel({
      loop:true,
      nav:true,
      navText:['<i class="fas fa-chevron-left"></i>','<i class="fas fa-chevron-right"></i>'],
      responsive:{
          0:{
              items:1
          },
          600:{
              items:1
          },
          1000:{
              items:1
          }
      }
  })
  
// brand-active
    $('.brand-active').owlCarousel({
      loop:true,
      nav:false,
      margin:50,
      navText:['<i class="fas fa-chevron-left"></i>','<i class="fas fa-chevron-right"></i>'],
      responsive:{
          0:{
              items:2
          },
          480:{
              items:2
          },
          
          768:{
              items:3
          },
          992:{
              items:4
          },
          1200:{
              items:6
          }
      }
  })


      // video propup
      $('.video').magnificPopup({
        type:'iframe',
     iframe: {
      markup: '<div class="mfp-iframe-scaler">'+
                '<div class="mfp-close"></div>'+
                '<iframe class="mfp-iframe" frameborder="0" allowfullscreen></iframe>'+
              '</div>', 
      patterns: {
        youtube: {
          index: 'youtube.com/', 
     
          id: 'v=',
          src: 'https://www.youtube.com/embed/%id%?autoplay=1' 
        },
        vimeo: {
          index: 'vimeo.com/',
          id: '/',
          src: '//player.vimeo.com/video/%id%?autoplay=1'
        },
        gmaps: {
          index: '//maps.google.',
          src: '%id%&output=embed'
        }
      },
      srcAction: 'iframe_src', 
     }  
     });
     new WOW().init ();


      // scrollUp
    $.scrollUp({
        scrollName: 'scrollUp', // Element ID
        topDistance: '300', // Distance from top before showing element (px)
        topSpeed: 300, // Speed back to top (ms)
        animation: 'fade', // Fade, slide, none
        animationInSpeed: 200, // Animation in speed (ms)
        animationOutSpeed: 200, // Animation out speed (ms)
        scrollText: '<i class="fas fa-angle-up"></i>', // Text for element
        activeOverlay: false, // Set CSS color to display scrollUp active point, e.g '#00FFFF'
      });
})



